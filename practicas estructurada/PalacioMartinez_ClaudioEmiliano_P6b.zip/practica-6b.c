#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//1. Desarrolle un programa que contenga la funci�n esPalindromo, la cual retorna
//un 1 si una palabra de pal�ndromo y un 0 en caso contrario. El programa debe
//solicitar al usuario ingresar una palabra y debe indicarle si la palabra ingresada
//es pal�ndroma o no.
//NOTA: una palabra pal�ndroma es aquella que se lee igual de derecha a
//izquierda como de izquierda a derecha. Ejemplo: reconocer.
//2. Desarrolle un programa que contenga la funci�n cantidadLetrasDiferentes, la
//cual regresa la cantidad de letras diferentes que contiene una cadena de
//caracteres. El programa debe decirle al usuario cuantas letras diferentes tiene
//la palabra y cuales son. Ejemplo: palabra tiene 5 letras diferentes p, a, l, b, r.
//3. Crear un programa llamado Apellido_Nombre_P6b.c el cual haga uso de las
//funciones creadas en los puntos anteriores. Probar sus funciones llam�ndolas
//al menos 3 veces con distintos par�metros para comprobar su correcto
//funcionamiento.
int palindromos(char *arreglo);
int cantidadLetrasDiferentes(char *cadena);
void pruebaFunciones(char* cadena);
int main(){
    char palabra[20],success,letras[20];
    printf("Dame la palabra:");
    gets(palabra);
    success = palindromos(palabra);
    printf("%d\nIntroduce cadena: ",success);
	gets(palabra);
	printf("\nNumero de letras diferentes en la cadena: %d", cantidadLetrasDiferentes(palabra));
    for(int i =0;i<3;i++){
        printf("\nPrueba %d\nIntroduce cadena para probar las 2 funciones anteriores: ",i);
        gets(palabra);
        pruebaFunciones(palabra);
    }
    return 0;
}
int palindromos(char *arreglo){
    int i,exito;
    if(strlen(arreglo)%2==1){
        for(i=0;i<strlen(arreglo)-1;i++){
            if(arreglo[i]==arreglo[strlen(arreglo)-1-i]){
                exito = 1;
            }
            else{
                return 0;
            }
        }
    }
    else{
        return 0;
    }
    return exito;
}
int cantidadLetrasDiferentes(char* cadena) {
	char letras[20],letra;
	int i,j,c = 0;
	for(i=0;i<strlen(cadena);i++){
        letras[i]=' ';
	}
	for (i = 0; i < strlen(cadena); ++i){
		j=0;
        do{
            if(letras[j]==cadena[i]){
                break;
            }
            else if(letras[j]==' '){
                letras[j]=cadena[i];
                c++;
                break;
            }
            j++;
        }while(j<strlen(letras));
	}
	for(i=0;i<c;i++){
        printf("%c",letras[i]);
	}
	return c;
}
void pruebaFunciones(char* cadena){
    int exito,c;
    exito = palindromos(cadena);
    printf("%d\n",exito);
    c = cantidadLetrasDiferentes(cadena);
}
