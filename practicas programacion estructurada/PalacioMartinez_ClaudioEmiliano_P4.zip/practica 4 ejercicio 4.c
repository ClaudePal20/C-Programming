#include <stdio.h>
//Cree un programa llamado Apellido_Nombre_P4_4.c el cual imprima el siguiente patrón según un número ingresado por el usuario.
int main(void) {
  int n,i,j,k;
  printf("Dame numero: ");
  scanf("%d",&n);
  for (i=0;i<n;i++)
    {
      for (j=n;j>=i;j--)
        {
          printf(" ");
        }
      for (k=0;k<=i;k++)
        {
          printf("*");
        }
      printf("\n");
    }
  return 0;
}