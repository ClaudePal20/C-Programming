/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
int main()
{
   int n, t, sum = 0, residuo;
   printf("Introduce un entero: \n");
   scanf("%d", &n);
   t = n;//Estamos usando otra variable con el mismo numero para imprimir el original despues
   while (t != 0)
   {
      residuo = t % 10; //El modulo de 10 nos deja el numero que sobra por lo general
      sum       = sum + residuo;
      t         = t / 10; //Lo dividimos entre 10 y a la siguiente nos dejara el residuo del otro digito
   }
   printf("La suma de digitos es: %d = %d\n", n, sum);
   return 0;
}