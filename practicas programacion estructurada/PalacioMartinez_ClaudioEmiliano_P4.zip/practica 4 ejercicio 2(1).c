/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <string.h>
int main()
{
    int longitud=100,i,sumpal=0;
    char a[longitud];
    printf("Introduce una frase: ");
    gets(a);
    longitud = strlen(a);
    for(i=0;i<longitud;i++){
        if(a[i]==' ')//Contamos palabras con espacios y para evitar conteos de mas establecemos una condicion forzada
        {
            sumpal=sumpal+1;
        }
    }
    sumpal++;
    printf("\nCantidad de palabras: %d",sumpal);
    return 0;
}
