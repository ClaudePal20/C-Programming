#include <stdio.h>
//Cree un programa llamado Apellido_Nombre_P2_2.c que solicite un número que representa la cantidad de segundos. El programa debe imprimir a cuantas horas, minutos y segundos corresponde la cantidad de segundos ingresada. Por ejemplo, si el usuario ingresa 125, el programa debe informar que 125 segundos equivalen a 0 horas, 2 minutos y 5 segundos.
int main(void) 
{
  float seg;
  printf("Dame la cantidad de segundos: ");
  scanf("%f",&seg);
  printf("La cantidad de horas es de %.0f con %i minutos y %i segundos",seg/60/60, (((int)seg/60)%60),((int)seg%60));
}