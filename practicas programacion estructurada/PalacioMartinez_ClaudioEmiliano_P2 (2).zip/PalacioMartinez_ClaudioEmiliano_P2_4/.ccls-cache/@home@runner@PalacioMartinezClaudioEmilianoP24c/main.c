#include <stdio.h>
//Cree un programa llamado Apellido_Nombre_P2_4.c que calcule la fuerza de atracción gravitacional entre dos cuerpos. El programa solicita la masa de dos objetos en kilogramos, y la distancia entre ambos cuerpos en metros e imprime la fuerza gravitacional entre ambos cuerpos. La ecuación de la ley de gravitación universal de Newton es: 
//F = G(m1*m2)/(r^2) Donde G es la constante gravitacional y es igual a 6.67*10^-11
int main(void) 
{
  double masa1, masa2, r,F;
  printf("Dame la masa del primer cuerpo en kilogramos:");
  scanf("%lf",&masa1);
  printf("Dame la masa del segundo cuerpo en kilogramos: ");
  scanf("%lf",&masa2);
  printf("Dame la distancia entre ambos cuerpos en metros:");
  scanf("%lf",&r);
  F =(0.0000000000667)*(masa1*masa2)/(r*r);
  printf("La fuerza gravitacional entre ambos cuerpos es de: %lf",F);
  return 0;
}