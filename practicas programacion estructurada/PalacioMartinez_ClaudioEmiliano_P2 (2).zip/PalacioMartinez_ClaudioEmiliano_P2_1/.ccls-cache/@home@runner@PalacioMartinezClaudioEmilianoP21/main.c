#include <stdio.h>
int main(void) 
//Cree un programa llamado Apellido_Nombre_P2_1.c que solicite dos números. El programa realiza las operaciones de suma, resta, multiplicación, división y módulo entre ambos números e imprime los resultados.

{
float a, b, mod;
  printf("Dame el numero a: ");
  scanf("%f",&a);
  printf("Dame el numero b: ");
  scanf("%f",&b);
  mod = (int)a%(int)b;
  printf("La suma de %f + %f da: %f", a, b, a+b);
  printf("\nLa resta de %f - %f da: %f", a, b, a-b);
  printf("\nLa division entre %f y %f da: %f", a, b, a/b);
  printf("\nLa multiplicacion de %f por %f da: %f", a, b, a*b);
  printf("\nEl modulo entre %f y %f nos deja un residuo de: %f",a,b,mod);
  return 0;
}