#include <stdio.h>

int main(void) 
{
    int a, b, c, d;
    int max, min;
    printf("imprime 4 numeros: \n");
    scanf("%i %i %i %i", &a, &b, &c, &d);
    if (a >= b && a >= c && a >= d)
      max = a;
    else if (b >= a && b >= c && b >= d)
      max = b;
    else if (c >= a && c >= b && c >= d)
      max = c;
    else
      max = d;
    if (a <= b && a <= c && a <= d)
      min = a;
    else if (b <= a && b <= c && b <= d)
      min = b;
    else if (c <= a && c <= b && c <= d)
      min = c;
    else
      min = d;
    printf("El mayor es %i y el menor es %i", max, min);
    return 0;
}