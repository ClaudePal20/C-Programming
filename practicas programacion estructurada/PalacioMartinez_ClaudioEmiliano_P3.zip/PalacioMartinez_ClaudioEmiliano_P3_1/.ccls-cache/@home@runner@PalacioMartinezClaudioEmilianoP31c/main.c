//Cree un programa llamado Apellido_Nombre_P3_1.c que despliegue un menú y despliegue un mensaje según la opción que el usuario seleccione. El menú debe contener al menos 3 opciones para seleccionar. 
#include <stdio.h>
int main(void) 
{
  int opc;
  printf("Elige una opcion:\n1. 2. 3.\n");
  scanf("%i",&opc);
  switch(opc)
    {
      case 1: 
        printf("Haz elegido la opcion 1");
        break;
      case 2: 
        printf("Haz elegido la opcion 2");
        break;
      case 3: 
        printf("Haz elegido la opcion 3");
        break;
      default: 
        printf("Opcion no existente");
    }
  return 0;
}