#include <stdio.h>
//Cree un programa llamado Apellido_Nombre_P3_3.c el cual permita al usuario capturar una cadena de caracteres. El programa debe mostrar un mensaje si la cadena ingresada esta capitalizada(si comienza con una letra mayúscula) o no.

int main(void) 
{
  char palabra[30];
  printf("Introduce una cadena de caracteres: ");
  scanf("%c", palabra);
  if (palabra[0]=='Q' || palabra[0]=='W' || palabra[0]=='E' || palabra[0]=='R' || palabra[0]=='T' || palabra[0]=='Y' || palabra[0]=='U' || palabra[0]=='I' || palabra[0]=='O' || palabra[0]=='P' || palabra[0]=='A' || palabra[0]=='S' || palabra[0]=='D' || palabra[0]=='F' || palabra[0]=='G' || palabra[0]=='H' || palabra[0]=='J' ||palabra[0]=='K' || palabra[0]=='L' || palabra[0]=='Z' || palabra[0]=='X' || palabra[0]=='C' || palabra[0]=='V' || palabra[0]=='B' || palabra[0]=='N' || palabra[0]=='M')
  {
    printf("La primera letra es mayúscula");
  }
  return 0;
}