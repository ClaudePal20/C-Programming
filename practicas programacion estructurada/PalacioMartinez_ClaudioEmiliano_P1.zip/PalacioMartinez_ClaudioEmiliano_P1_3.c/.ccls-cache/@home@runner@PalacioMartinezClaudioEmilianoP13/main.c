#include <stdio.h>

int main() 
{
  //El programa solicita la captura de la estatura del usuario y su peso. El programa
  //imprime el Índice de Masa Corporal.
  float IMC, peso, altura;
  printf("Introduce tu peso en kilos: ");
  scanf("%f", & peso);
  printf("Introduce tu altura en metros: ");
  scanf("%f", & altura);
  IMC = peso/(altura*altura);
  printf("Tu IMC es de: %f",IMC);
  return 0;
}