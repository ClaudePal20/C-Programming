#include <stdio.h>

int main(void) {
  float calif1, calif2, calif3, calif4, calif5, promedio; //declaramos variables de califs
  printf("Dame las calificaciones\n"); //pedimos califs
  scanf("%f %f %f %f %f", &calif1, &calif2, &calif3, &calif4, &calif5); //escaneamos califs
  promedio = (calif1 + calif2 + calif3 + calif4 + calif5)/5; //calculamos promedio
  printf("El promedio es de: %f",promedio); //imprimimos promedio
}