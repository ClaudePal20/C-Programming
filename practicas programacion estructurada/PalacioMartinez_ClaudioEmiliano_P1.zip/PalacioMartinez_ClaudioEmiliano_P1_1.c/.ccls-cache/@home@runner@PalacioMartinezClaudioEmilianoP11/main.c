#include <stdio.h>

int main()
{
    char carac, nombre[20];
  
    printf("Introduce un caracter: "); //Punto a
    carac = getchar();
    printf("\nEl caracter es: ");
    putchar(carac);
  
    printf("\n\nDame tu nombre: "); //Punto B (puse doble salto para que saltara 1 espacio)
    scanf("%s.",nombre);
  
    printf("\nHola, %s",nombre); //Punto C
  }